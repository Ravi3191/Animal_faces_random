import numpy as np
import os
import random

#set directories
dirname = os.path.dirname(__file__)
directory = str('common/')
directory = os.path.join(dirname, directory)

target_directory = [str('dog'),str('cat'),str('wild')]
data_set_percent_size = [float(0.33),float(0.5),float(1.0)]

#print(os.listdir(directory))

#print(files)

# select a percent of the files randomly 
for i in range(3):

	# list all files in dir that are an image
	files = [f for f in os.listdir(directory) if f.endswith('.jpg')]

	random_files = random.sample(files, int(len(files)*data_set_percent_size[i]))

	# move the randomly selected images by renaming directory 

	for random_file_name in random_files:      
	    #print(directory+'/'+random_file_name)
	    #print(target_directory+'/'+random_file_name)
	    current_target_directory = os.path.join(dirname,target_directory[i])
	    os.rename(directory+'/'+random_file_name, current_target_directory +'/'+random_file_name)
	    continue
